let display=document.getElementById("display");
let mybtn=document.querySelectorAll("button");
let currentdisplay="";
for(let items of mybtn){
  items.addEventListener("click",e=>{
    mybtntext=e.target.innerText;
    console.log(mybtntext);
    if(mybtntext=="C"){
      currentdisplay="";
      display.value=currentdisplay;
    }
    else if(mybtntext=="="){
      display.value=eval(currentdisplay);
    }
    else{
      currentdisplay=currentdisplay+mybtntext;
      display.value=currentdisplay;
    }
  })
}
